<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="uk">
<context>
    <name>AddTransparencySliderPlugin</name>
    <message>
        <location filename="../add_transparency_slider.py"/>
        <source>Add transparency slider</source>
        <translation>Додати повзунок прозорості</translation>
    </message>
    <message>
        <location filename="../add_transparency_slider.py"/>
        <source>Remove transparency slider</source>
        <translation>Видалити повзунок прозорості</translation>
    </message>
</context>
</TS>
