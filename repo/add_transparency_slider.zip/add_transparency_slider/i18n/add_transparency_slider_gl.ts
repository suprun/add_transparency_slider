<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="gl">
<context>
    <name>AddTransparencySliderPlugin</name>
    <message>
        <location filename="../add_transparency_slider.py"/>
        <source>Add transparency slider</source>
        <translation>Engadir control deslizante de transparencia</translation>
    </message>
    <message>
        <location filename="../add_transparency_slider.py"/>
        <source>Remove transparency slider</source>
        <translation>Eliminar control deslizante de transparencia</translation>
    </message>
</context>
</TS>
