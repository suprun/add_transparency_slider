<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="mr">
<context>
    <name>AddTransparencySliderPlugin</name>
    <message>
        <location filename="../add_transparency_slider.py"/>
        <source>Add transparency slider</source>
        <translation>पारदर्शकता स्लाइडर जोडा</translation>
    </message>
</context>
</TS>
