<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="he">
<context>
    <name>AddTransparencySliderPlugin</name>
    <message>
        <location filename="../add_transparency_slider.py"/>
        <source>Add transparency slider</source>
        <translation>הוספת מחוון שקיפות</translation>
    </message>
</context>
</TS>
